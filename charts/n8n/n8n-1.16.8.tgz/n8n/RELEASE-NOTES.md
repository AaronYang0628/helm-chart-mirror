# Changelog

- **Changed**: Update n8nio/n8n image version to 1.122.5
    - [Upstream Project](https://github.com/n8n-io/n8n)
